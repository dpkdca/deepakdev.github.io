# 📗 Table of Contents

- [📖 About the Project](#about-project)
  - [🛠️ Built With](#built-with)
    - [Tech Stack](#tech-stack)
    - [Key Features](#key-features)
  - [🚀 Live Demo](#live-demo)
- [💻 Getting Started](#getting-started)
  - [Setup](#setup)
  - [Prerequisites](#prerequisites)
  - [Install](#install)
  - [Usage](#usage)
  - [Run tests](#run-tests)
  - [Deployment](#triangular_flag_on_post-deployment)
- [👥 Authors](#authors)
- [🔭 Future Features](#future-features)
- [🤝 Contributing](#contributing)
- [⭐ Show your support](#support)
- [🙏 Acknowledgements](#acknowledgements)
- [📝 License](#license)

<!-- PROJECT DESCRIPTION -->

# 📖 My Portfolio Website (Mobile) <a name="about-project"></a>

**My Portfolio Website** is a simple personal portfolio website that provides information about what I do, what services I may offer, and how to contact me or my company.
## 🛠️ Built With <a name="built-with"></a>

<details>
  <summary>Client</summary>
  <ul>
    <li><a href="">HTML</a></li>
   <li><a href="">CSS</a></li>   
  </ul>
</details>

### Tech Stack <a name="tech-stack"></a>

<!-- Features -->

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- LIVE DEMO -->

## 🚀 Live Demo <a name="live-demo"></a>

- https://christianonoh.github.io/Portfolio-Website/

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- GETTING STARTED -->

## 💻 Getting Started <a name="getting-started"></a>

To get a local copy up and running, follow these steps.

### Prerequisites

In order to run this project you need:

- have installed a code editor.

### Setup

Clone this repository to your desired folder:

cd my-folder [https://github.com/christianonoh/Portfolio-Website.git]

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- AUTHORS -->

## 👥 Authors <a name="authors"></a>

> Mention all of the collaborators of this project.
👤 **Author**

- GitHub: [@christianonoh](https://github.com/christianonoh)
- Twitter: [@onohchristian](https://twitter.com/OnohChristian)
- LinkedIn: [LinkedIn](https://www.linkedin.com/in/christianonoh/)

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- FUTURE FEATURES -->


## 🔭 Future Features <a name="future-features"></a>
- Responsiveness
- Contact Form

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- CONTRIBUTING -->

## 🤝 Contributing <a name="contributing"></a>

Contributions, issues, and feature requests are welcome!

Feel free to check the [issues page](../../issues/).

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- SUPPORT -->

## ⭐ Show your support <a name="support"></a>

If you like this project follow and add a star.

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- ACKNOWLEDGEMENTS -->

## 🙏 Acknowledgments <a name="acknowledgements"></a>

I would like to thank my coding partners...

<p align="right">(<a href="#readme-top">back to top</a>)</p>

<!-- LICENSE -->

## 📝 License <a name="license"></a>

This project is [MIT](./LICENSE) licensed.
